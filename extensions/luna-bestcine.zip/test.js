const start=document.querySelector('#start'),cancel=document.querySelector('#cancel'),status=document.querySelector('#status'),video=document.querySelector('video'),result=document.querySelector('#result');let port,timer;
function reset(){clearInterval(timer);port?.disconnect();port=null;video.pause();video.removeAttribute('src');video.load();start.disabled=false;cancel.disabled=true;}
cancel.onclick=()=>{reset();status.textContent='Teste encerrado.'};
start.onclick=()=>{
 reset();start.disabled=true;cancel.disabled=false;result.textContent='';port=chrome.runtime.connect({name:'luna-bestcine-test'});
 port.onDisconnect.addListener(()=>{clearInterval(timer);if(start.disabled)status.textContent='A conexão com a extensão foi encerrada. Recarregue o teste.'});
 port.onMessage.addListener(message=>{
  if(message.type==='phase')status.textContent=message.text;
  if(message.type==='error'){const text=message.text;reset();status.textContent=text;}
  if(message.type==='ready'){
   video.onloadedmetadata=()=>{if(video.duration<600){reset();status.textContent='Falhou: clipe curto substituiu o episódio.';return;}result.textContent=JSON.stringify({duration:video.duration,totalMB:(message.total/1048576).toFixed(1),mode:'Trechos de até 1 MB'},null,2);status.textContent='Pronto. Clique em reproduzir se não iniciar automaticamente.';video.play().catch(()=>{});};
   video.onplaying=()=>status.textContent='Reproduzindo por trechos. Confira o áudio em português.';
   video.onwaiting=()=>status.textContent='Carregando próximo trecho…';video.onerror=()=>status.textContent='Erro ao carregar o vídeo: '+video.error?.code+'. Informe esta mensagem.';
   video.src=message.url;video.preload='auto';video.load();status.textContent='Carregando o início do vídeo…';
  }
 });timer=setInterval(()=>port?.postMessage({op:'ping'}),20000);port.postMessage({op:'start'});
};
window.addEventListener('pagehide',reset);
