export const pieceBytes=1024*1024;
export function videoRange(header,total){
 if(!Number.isSafeInteger(total)||total<1)throw Error('Tamanho inválido');
 if(!header)return {start:0,end:Math.min(pieceBytes-1,total-1)};
 const m=/^bytes=(\d*)-(\d*)$/.exec(header);if(!m||!m[1]&&!m[2])throw Error('Intervalo inválido');
 let start,end;if(!m[1]){const suffix=Number(m[2]);if(!Number.isSafeInteger(suffix)||suffix<1)throw Error('Intervalo inválido');start=Math.max(0,total-suffix);end=total-1;}
 else{start=Number(m[1]);end=m[2]?Number(m[2]):total-1;}
 if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=total||end<start)throw Error('Intervalo inválido');
 return {start,end:Math.min(end,start+pieceBytes-1,total-1)};
}
export async function streamPiece(request,url,total,signal,networkFetch=fetch){
 let range;try{range=videoRange(request.headers.get('range'),total)}catch{return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+total}})}
 const upstream=await networkFetch(url,{headers:{Range:`bytes=${range.start}-${range.end}`},signal,credentials:'omit',redirect:'error'});
 const expected=`bytes ${range.start}-${range.end}/${total}`;
 if(upstream.status!==206||upstream.headers.get('content-range')!==expected||!/^video\/mp4(?:;|$)/i.test(upstream.headers.get('content-type')||'')){await upstream.body?.cancel();throw Error('A origem não respeitou o trecho solicitado.');}
 let received=0;const length=range.end-range.start+1;
 const body=upstream.body.pipeThrough(new TransformStream({transform(chunk,c){received+=chunk.length;if(received>length)throw Error('Trecho maior que o permitido');c.enqueue(chunk);},flush(){if(received!==length)throw Error('Trecho incompleto')}}));
 return new Response(body,{status:206,headers:{'Content-Type':'video/mp4','Content-Length':String(length),'Content-Range':expected,'Accept-Ranges':'bytes','Cache-Control':'no-store'}});
}
