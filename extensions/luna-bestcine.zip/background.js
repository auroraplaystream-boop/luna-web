import {permitted,validateVideo} from './policy.mjs';
import {readPiece} from './streaming.mjs';
chrome.runtime.onConnect.addListener(port=>{
 const sender=port.sender?.url||'';let trusted=false;try{const u=new URL(sender);trusted=u.origin==='https://auroraplaystream-boop.github.io'&&u.pathname.startsWith('/luna-web/')}catch{}
 if(port.name!=='luna-bestcine-test'||port.sender?.id!==chrome.runtime.id||!trusted)return;
 const abort=new AbortController();let source,total,started=false,busy=0;
 port.onDisconnect.addListener(()=>abort.abort());
 port.onMessage.addListener(async input=>{
  if(input?.op==='cancel'){abort.abort();return;}if(input?.op==='ping')return;
  const send=data=>{if(!abort.signal.aborted)port.postMessage(data)};
  try{
   if(input?.op==='start'&&!started){if(!['movie','series'].includes(input.type)||typeof input.videoId!=='string'||!/^tt\d{1,12}(?::\d{1,4}:\d{1,5})?$/.test(input.videoId))throw Error('Título ou episódio inválido.');started=true;send({type:'phase',text:'Consultando o BestCine…'});
    let r,last;for(let attempt=0;attempt<2;attempt++){try{r=await fetch('https://bestcine.dpdns.org/stream/'+input.type+'/'+encodeURIComponent(input.videoId)+'.json',{signal:AbortSignal.any([abort.signal,AbortSignal.timeout(12000)]),credentials:'omit'});if(!r.ok)throw Error('Consulta do addon: HTTP '+r.status);break;}catch(e){last=e;if(abort.signal.aborted)throw e;}}if(!r?.ok)throw Error('O addon não respondeu: '+last?.message);
    const data=await r.json();if(input.videoId==='tt13759970:1:1')throw Error('O BestCine associou este episódio a A.Riza. Escolha outra fonte para Taxi Driver.');const rows=data.streams||[];let row;if(input.sourceName&&input.sourceTitle){const matches=s=>s.name===input.sourceName&&s.title===input.sourceTitle&&permitted(s.url);const indexed=Number.isInteger(input.sourceIndex)?rows[input.sourceIndex]:null;const same=rows.filter(matches);row=indexed&&matches(indexed)?indexed:same.length===1?same[0]:null;}else row=data.streams?.find(s=>/Servidor Athena/.test(s.title||'')&&/Dublado/.test(s.title||'')&&permitted(s.url))||(!input.sourceName?data.streams?.find(s=>/Dublado/.test(s.title||'')&&permitted(s.url)):null);if(!row)throw Error('Nenhuma fonte MP4 direta dublada foi encontrada para este título.');
    send({type:'phase',text:'Abrindo leitura por trechos…'});
    let media,match,lastMedia;const alternatives=input.sourceName?[row]:[row,...rows.filter(s=>/Dublado/.test(s.title||'')&&permitted(s.url)&&s!==row)].slice(0,3);
    for(const candidate of alternatives){try{media=await fetch(candidate.url,{headers:{Range:'bytes=0-1023'},signal:AbortSignal.any([abort.signal,AbortSignal.timeout(8000)]),credentials:'omit'});validateVideo(media);match=/^bytes 0-1023\/(\d+)$/.exec(media.headers.get('content-range')||'');await media.body?.cancel();if(media.status!==206||!match)throw Error('Servidor não aceita leitura por trechos.');break;}catch(e){await media?.body?.cancel().catch(()=>{});media=undefined;match=null;lastMedia=e;if(abort.signal.aborted)throw e;}}
    if(!media||!match)throw Error('As fontes não responderam à leitura por trechos: '+lastMedia?.message);
    total=Number(match[1]);source=media.url;send({type:'ready',total});return;
   }
   if(input?.op==='read'){
    if(!source||busy>=3||!Number.isSafeInteger(input.offset)||input.offset<0||input.offset>=total||!Number.isSafeInteger(input.id))throw Error('Pedido de trecho inválido.');busy++;
    try{const end=Math.min(total-1,input.offset+1024*1024-1);const bytes=await readPiece(new Request('https://extension.invalid/media',{headers:{Range:`bytes=${input.offset}-${end}`}}),source,total,AbortSignal.any([abort.signal,AbortSignal.timeout(25000)]));
     let binary='';for(const b of bytes)binary+=String.fromCharCode(b);send({type:'piece',id:input.id,offset:input.offset,data:btoa(binary),length:bytes.length});
    }finally{busy--;}
   }
  }catch(e){send({type:'error',text:e.message,id:input?.id});}
 });
});
